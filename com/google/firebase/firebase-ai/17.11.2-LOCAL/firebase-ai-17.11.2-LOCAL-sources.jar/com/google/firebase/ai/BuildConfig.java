/**
 * Automatically generated file. DO NOT MODIFY
 */
package com.google.firebase.ai;

public final class BuildConfig {
  public static final boolean DEBUG = false;
  public static final String LIBRARY_PACKAGE_NAME = "com.google.firebase.ai";
  public static final String BUILD_TYPE = "release";
  // Field from default config.
  public static final String VERSION_NAME = "17.11.2-LOCAL";
}
