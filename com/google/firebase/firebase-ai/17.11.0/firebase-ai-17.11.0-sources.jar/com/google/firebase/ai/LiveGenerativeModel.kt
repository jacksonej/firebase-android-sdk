/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.firebase.ai

import com.google.firebase.FirebaseApp
import com.google.firebase.ai.common.APIController
import com.google.firebase.ai.common.AppCheckHeaderProvider
import com.google.firebase.ai.common.JSON
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.GenerativeBackend
import com.google.firebase.ai.type.LiveClientSetupMessage
import com.google.firebase.ai.type.LiveGenerationConfig
import com.google.firebase.ai.type.LiveSession
import com.google.firebase.ai.type.PublicPreviewAPI
import com.google.firebase.ai.type.RequestOptions
import com.google.firebase.ai.type.ServiceConnectionHandshakeFailedException
import com.google.firebase.ai.type.Tool
import com.google.firebase.annotations.concurrent.Blocking
import com.google.firebase.appcheck.interop.InteropAppCheckTokenProvider
import com.google.firebase.auth.internal.InternalAuthProvider
import io.ktor.client.plugins.websocket.DefaultClientWebSocketSession
import io.ktor.websocket.Frame
import io.ktor.websocket.close
import io.ktor.websocket.readBytes
import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.channels.ClosedReceiveChannelException
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.JsonObject

/**
 * Represents a multimodal model (like Gemini) capable of real-time content generation based on
 * various input types, supporting bidirectional streaming.
 */
@PublicPreviewAPI
public class LiveGenerativeModel
internal constructor(
  private val modelName: String,
  @Blocking private val blockingDispatcher: CoroutineContext,
  private val config: LiveGenerationConfig? = null,
  private val tools: List<Tool> = emptyList(),
  private val systemInstruction: Content? = null,
  private val location: String,
  private val firebaseApp: FirebaseApp,
  private val controller: APIController
) {
  internal constructor(
    modelName: String,
    apiKey: String,
    firebaseApp: FirebaseApp,
    blockingDispatcher: CoroutineContext,
    config: LiveGenerationConfig? = null,
    tools: List<Tool> = emptyList(),
    systemInstruction: Content? = null,
    location: String = "us-central1",
    requestOptions: RequestOptions = RequestOptions(),
    appCheckTokenProvider: InteropAppCheckTokenProvider? = null,
    internalAuthProvider: InternalAuthProvider? = null,
    generativeBackend: GenerativeBackend,
    useLimitedUseAppCheckTokens: Boolean,
  ) : this(
    modelName,
    blockingDispatcher,
    config,
    tools,
    systemInstruction,
    location,
    firebaseApp,
    APIController(
      apiKey,
      modelName,
      requestOptions,
      "gl-kotlin/${KotlinVersion.CURRENT}-ai fire/${BuildConfig.VERSION_NAME}",
      firebaseApp,
      AppCheckHeaderProvider(
        TAG,
        useLimitedUseAppCheckTokens,
        appCheckTokenProvider,
        internalAuthProvider
      ),
      generativeBackend
    ),
  )

  /**
   * Start a [LiveSession] with the server for bidirectional streaming.
   *
   * @return A [LiveSession] that you can use to stream messages to and from the server.
   * @throws [ServiceConnectionHandshakeFailedException] If the client was not able to establish a
   * connection with the server.
   */
  @OptIn(ExperimentalSerializationApi::class)
  public suspend fun connect(): LiveSession {
    val clientMessage =
      LiveClientSetupMessage(
          modelName,
          config?.toInternal(),
          tools.map { it.toInternal() }.takeIf { it.isNotEmpty() },
          systemInstruction?.toInternal(),
          config?.inputAudioTranscription?.toInternal(),
          config?.outputAudioTranscription?.toInternal()
        )
        .toInternal()
    val data: String = JSON.encodeToString(clientMessage)
    var webSession: DefaultClientWebSocketSession? = null
    try {
      webSession = controller.getWebSocketSession(location)
      webSession.send(Frame.Text(data))
      val receivedJsonStr = webSession.incoming.receive().readBytes().toString(Charsets.UTF_8)
      val receivedJson = JSON.parseToJsonElement(receivedJsonStr)

      return if (receivedJson is JsonObject && "setupComplete" in receivedJson) {
        LiveSession(
          session = webSession,
          blockingDispatcher = blockingDispatcher,
          firebaseApp = firebaseApp
        )
      } else {
        webSession.close()
        throw ServiceConnectionHandshakeFailedException("Unable to connect to the server")
      }
    } catch (e: ClosedReceiveChannelException) {
      val reason = webSession?.closeReason?.await()
      val message =
        "Channel was closed by the server.${if (reason != null) " Details: ${reason.message}" else ""}"
      throw ServiceConnectionHandshakeFailedException(message, e)
    }
  }

  private companion object {
    private val TAG = LiveGenerativeModel::class.java.simpleName
  }
}
