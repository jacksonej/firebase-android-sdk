/*
 * Copyright 2026 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.firebase.ai.generativemodel

import android.util.Log
import com.google.firebase.ai.ondevice.interop.FirebaseAIOnDeviceException
import com.google.firebase.ai.type.Content
import com.google.firebase.ai.type.CountTokensResponse
import com.google.firebase.ai.type.FirebaseAIException
import com.google.firebase.ai.type.GenerateContentResponse
import com.google.firebase.ai.type.GenerateObjectResponse
import com.google.firebase.ai.type.JsonSchema
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.onEach

/**
 * A [GenerativeModelProvider] that delegates requests to a `defaultModel` and falls back to a
 * `fallbackModel` under specified conditions.
 *
 * This class provides a mechanism to attempt an operation with a primary model, and if a
 * precondition is not met or a [FirebaseAIException] occurs (and configured to do so), it switches
 * to a secondary fallback model.
 *
 * @param defaultModel The primary [GenerativeModelProvider] to use for generating content.
 * @param fallbackModel The secondary [GenerativeModelProvider] to use if the `defaultModel` cannot
 * be used or encounters an exception.
 * @param precondition A lambda function that returns `true` if the `defaultModel` should be used,
 * or `false` to immediately use the `fallbackModel`. Defaults to always `true`.
 * @param shouldFallbackInException If `true`, the `fallbackModel` will be used when the
 * `defaultModel` throws a [FirebaseAIException]. If `false`, the exception will be rethrown.
 * Defaults to `true`.
 */
internal class FallbackGenerativeModelProvider(
  internal val defaultModel: GenerativeModelProvider,
  internal val fallbackModel: GenerativeModelProvider,
  private val precondition: () -> Boolean = { true },
  private val shouldFallbackInException: Boolean = true
) : GenerativeModelProvider {

  override suspend fun generateContent(prompt: List<Content>): GenerateContentResponse {
    return withFallback("generateContent") { generateContent(prompt) }
  }

  override suspend fun countTokens(prompt: List<Content>): CountTokensResponse {
    return withFallback("countTokens") { countTokens(prompt) }
  }

  override fun generateContentStream(prompt: List<Content>): Flow<GenerateContentResponse> {
    return withFlowFallback("generateContentStream") { generateContentStream(prompt) }
  }

  override suspend fun <T : Any> generateObject(
    jsonSchema: JsonSchema<T>,
    prompt: List<Content>
  ): GenerateObjectResponse<T> {
    return withFallback("generateObject") { generateObject(jsonSchema, prompt) }
  }

  // Calling warmup in both `defaultModel` and `fallbackModel` is necessary as it's only meaningful
  // for on-device model. It's a no-op for cloud models.
  override suspend fun warmUp() {
    defaultModel.warmUp()
    fallbackModel.warmUp()
  }

  private inline fun <T> withFallback(
    methodName: String,
    block: GenerativeModelProvider.() -> T
  ): T {
    if (!precondition()) {
      Log.w(
        TAG,
        "Precondition was not met, switching to fallback model `${fallbackModel.javaClass.simpleName}`"
      )
      return fallbackModel.block()
    }
    return try {
      defaultModel.block()
    } catch (e: Exception) {
      if (
        shouldFallbackInException && (e is FirebaseAIException || e is FirebaseAIOnDeviceException)
      ) {
        Log.w(
          TAG,
          "Error running `$methodName` on `${defaultModel.javaClass.simpleName}`. Falling back to `${fallbackModel.javaClass.simpleName}`",
          e
        )
        return fallbackModel.block()
      }
      throw e
    }
  }

  // Flow-based fallback differs significantly from regular call fallback, primarily due to:
  //
  // 1. Exception Timing: Exceptions are thrown during *flow collection*, not at flow creation.
  //    Therefore, a *wrapper flow* is utilized to manage emitting either default or fallback
  //    elements.
  // 2. Partial Collection Rule: If a flow collection has *successfully started* before an exception
  //    occurs, *no fallback* should be triggered. This prevents inconsistent or mixed responses,
  //    where partial data from one source could be combined with data from another.
  private inline fun <T> withFlowFallback(
    methodName: String,
    crossinline block: GenerativeModelProvider.() -> Flow<T>
  ): Flow<T> {
    if (!precondition()) {
      Log.w(
        TAG,
        "Precondition was not met, switching to fallback model `${fallbackModel.javaClass.simpleName}`"
      )
      return fallbackModel.block()
    }
    return flow {
      var hasEmitted = false
      val defaultFlow = defaultModel.block().onEach { hasEmitted = true }
      try {
        emitAll(defaultFlow)
      } catch (e: Exception) {
        if (
          !hasEmitted &&
            shouldFallbackInException &&
            (e is FirebaseAIException || e is FirebaseAIOnDeviceException)
        ) {
          Log.w(
            TAG,
            "Error running `$methodName` on `${defaultModel.javaClass.simpleName}`. Falling back to `${fallbackModel.javaClass.simpleName}`",
            e
          )
          emitAll(fallbackModel.block())
        } else {
          throw e
        }
      }
    }
  }

  companion object {
    private val TAG = FallbackGenerativeModelProvider::class.java.simpleName
  }
}
